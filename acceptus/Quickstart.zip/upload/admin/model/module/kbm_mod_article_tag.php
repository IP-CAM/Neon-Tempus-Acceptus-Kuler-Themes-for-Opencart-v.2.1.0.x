<?php
class ModelModuleKBMModArticleTag extends Model
{

}