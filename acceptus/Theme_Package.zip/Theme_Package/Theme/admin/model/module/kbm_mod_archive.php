<?php
class ModelModuleKBMModArchive extends Model
{

}