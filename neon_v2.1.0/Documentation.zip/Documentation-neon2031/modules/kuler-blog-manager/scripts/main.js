'use strict';

angular.module('themeDocument', ['ngCookies', 'ngSanitize', 'ngRoute', 'ui.bootstrap'])
  .controller('NavigationCtrl', function ($scope, $location) {
    $scope.isSelected = function (matchRoute) {
      if ($scope.selectedRoute && $scope.selectedRoute.route === '/' + matchRoute) {
        return true;
      }
    };

    $scope.$watch(function () {
        return $location.path();
      }, function (newPath) {
        newPath = newPath || '/intro';

        $scope.selectedRoute = {
          route: newPath,
          templateUrl: 'partials' + newPath + '.html'
        };

        $('#content').html('Loading...');
    });

    $scope.onPartialLoaded = function () {
      $("html, body").animate({ scrollTop: 0 }, 300);
    };
  });

var $navContainer = $('#navigation-container'),
  navContainerTop = $navContainer.offset().top;

$(window).on('scroll', function () {
  if ($(window).scrollTop() >= navContainerTop) {
    $navContainer.addClass('stick');
  } else {
    $navContainer.removeClass('stick');
  }
});

$(window).on('resize', function () {
  if (!$navContainer.hasClass('stick')) {
    $('#navigation').height($(window).height() - 60 - $('header').outerHeight() - $('#sidebar-container').outerHeight());
  } else {
    $('#navigation').height($(window).height() - $('#sidebar-container').height());
  }
});

$(document).ready(function () {
  $(window).trigger('resize');
});