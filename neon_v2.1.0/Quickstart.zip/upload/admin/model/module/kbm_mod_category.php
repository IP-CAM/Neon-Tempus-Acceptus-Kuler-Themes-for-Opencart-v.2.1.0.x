<?php
class ModelModuleKBMModCategory extends Model
{

}