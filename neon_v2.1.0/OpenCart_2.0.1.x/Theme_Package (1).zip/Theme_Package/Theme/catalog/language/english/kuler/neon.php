<?php
$_['text_carousel'] = 'Brands';
$_['text_vertical_menu'] = 'Categories';
$_['text_product_details'] = 'Product Details';
$_['text_related_products'] = 'YOU MAY ALSO LIKE';
$_['text_welcome'] = 'WELCOME GUEST!';
$_['text_or'] = 'OR';
$_['text_my_compare'] = 'Compare';
$_['text_my_wishlist'] = 'Wishlist';
$_['text_readmore'] = 'Read More';
$_['text_submit_comment'] = 'Post Your Comment';