<?php
class ModelModuleKBMModRecentArticle extends Model
{

}