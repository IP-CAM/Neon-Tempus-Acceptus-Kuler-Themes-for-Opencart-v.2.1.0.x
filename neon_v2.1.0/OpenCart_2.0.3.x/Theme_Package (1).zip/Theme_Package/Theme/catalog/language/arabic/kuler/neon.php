<?php
$_['text_product_details'] = 'تفاصيل المنتج';
$_['text_related_products'] = 'قد ترغب أيضا';