<?php
$_['heading_module']        = 'Kuler Showcase';

$_['text_years']           = 'Years';
$_['text_months']          = 'Months';
$_['text_weeks']           = 'Weeks';
$_['text_days']            = 'Days';
$_['text_hours']           = 'Hours';
$_['text_minutes']         = 'Minutes';
$_['text_seconds']         = 'Seconds';
$_['text_year']            = 'Year';
$_['text_month']           = 'Month';
$_['text_week']            = 'Week';
$_['text_day']             = 'Day';
$_['text_hour']            = 'Hour';
$_['text_minute']          = 'Minute';
$_['text_second']          = 'Second';
