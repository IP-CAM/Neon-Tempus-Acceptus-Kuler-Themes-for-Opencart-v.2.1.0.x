<?php

$_['text_x_items_tagged_with_y'] = '%d items tagged with %s';