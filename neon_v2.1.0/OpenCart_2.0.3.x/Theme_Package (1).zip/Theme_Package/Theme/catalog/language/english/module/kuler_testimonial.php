<?php
$_['heading_module']        = 'Kuler Testimonial';

$_['button_send_message']   = 'Send Message';