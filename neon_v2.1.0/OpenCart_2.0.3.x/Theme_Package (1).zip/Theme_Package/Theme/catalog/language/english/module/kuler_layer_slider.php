<?php
$_['heading_title'] = 'Kuler Layer Slider';