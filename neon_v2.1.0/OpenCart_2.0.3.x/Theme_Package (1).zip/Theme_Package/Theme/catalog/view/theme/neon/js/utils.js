Kuler.waitHtml = '<i class="fa fa-circle-o-notch fa-spin wait"></i>';

(function () {
	var $notification = $('#notification'),
		timer;

	if (Kuler.show_custom_notification) {
		Kuler.notification_show_time = parseInt(Kuler.notification_show_time) || 2500;
	}

	function kulerAlert(type, message) {
		if (!$notification.length) {
			$notification = $('#notification');
		}

		clearTimeout(timer);

		$notification
			.html('<div class="alert alert-'+ type +'">' + message + '</div>');

		if (Kuler.show_custom_notification) {
			$notification
				.addClass('active')
				.children()
					.css('display', 'none')
					.fadeIn('slow', function () {
						timer = setTimeout(function () {
							$notification.removeClass('active');
						}, Kuler.notification_show_time);
					});
		} else {
			$('html, body').animate({ scrollTop: 0 }, 'slow');
		}
	}

	window.kulerAlert = kulerAlert;
})();

if (Kuler.show_quick_view) {
    function initQuickView(selector) {
	    $(selector).on('click', function (evt) {
		    evt.preventDefault();

		    var $el = $(this);

		    $.magnificPopup.open({
			    items: {
				    src: this.href || $el.data('href')
			    },
			    type: 'iframe',
			    mainClass: 'mfp-fade'
		    });
        });
    };
}

jQuery(document).ready(function ($) {
	var $window = $(window);

    // Fixed Header
    if (Kuler.fixed_header) {
        $(".header").headroom({
            "offset": 41
        });
    }

    // Currency
    $('#currency a').on('click', function(e) {
        e.preventDefault();

        $('#currency input[name=\'currency_code\']').attr('value', $(this).attr('href'));

        $('#currency').submit();
    });

    // Language
    $('#language a').on('click', function(e) {
        e.preventDefault();

        $('#language input[name=\'language_code\']').attr('value', $(this).attr('href'));

        $('#language').submit();
    });

    var $dropdownContainer = $('.dropdown-container');

    $dropdownContainer.find('.dropdown-toggle').on('click', function () {
        $(this).next().toggleClass('open');
    });

    $('body').on('click', function (evt) {
        if (!$(evt.target).parents('.dropdown-container').length) {
            $('#language, #currency, .links').find('.open').removeClass('open');
        }
    });

	// Quick View
	if (Kuler.show_quick_view) {
        initQuickView('.product-detail-button--quick-view');

        setTimeout(function () {
            initQuickView('.product-detail-button--quick-view');
        }, 1000);
	}

	// Newsletter
	if (Kuler.show_newsletter) {
		$('#newsletter-form').on('submit', function () {
			var $mail = $('#newsletter-mail'),
				$button = $('#newsletter-submit'),
				mail = $mail.val();

			if (!mail) {
				return false;
			}

			$mail.prop('disabled', true);
			$button.prop('disabled', true);
			$button.after(Kuler.waitHtml);

			$.post(Kuler.newsletter_subscribe_link, {
				mail: mail
			}, function (data) {
				var type = data.status ? 'success' : 'error';

				kulerAlert(type, data.message);

				$mail.prop('disabled', false);
				$button.prop('disabled', false);

				$button.next().remove();
			}, 'json');

			return false;
		});
	}

	//Smooth scroll to on page element
    $('body[class*="product-product"] .write-review').on('click', function(event){
        event.preventDefault();

        //go to destination
        $('html,body').animate({scrollTop: $('.product-tabs').offset().top - 300}, 500,'swing');
     });

	// Scroll up
	if (Kuler.enable_scroll_up) {
		var $scrollup = $('.scrollup');

		$window.scroll(function() {
			if ($window.scrollTop() > 300) {
				$scrollup.addClass('show');
			} else {
				$scrollup.removeClass('show');
			}
		});

		$scrollup.on('click', function(evt) {
			$("html, body").animate({ scrollTop: 0 }, 600);
			evt.preventDefault();
		});
	}

	if (Kuler.category_menu_type === 'accordion') {
		var $boxCategory = $('.box-category');

		$('.box-category .toggle').on('click', function () {
			var $this = $(this);

			$boxCategory
				.find('li.active')
					.removeClass('active')
					.find('ul')
						.slideUp();
			$this.next().slideDown();
			$this.parent().addClass('active');
		});
	}

	// Setup mobile main menu
	$('#btn-mobile-toggle').on('click', function () {
		var $btn = $(this);

		if ($btn.hasClass('expand')) {
			$btn.removeClass('expand')
				.next().slideUp();
		} else {
			$btn.addClass('expand')
				.next()
				.slideDown();
		}
	});

	$('.btn-expand-menu').on('click', function () {
		var $btn = $(this);

		if ($btn.parent().hasClass('expand')) {
			$btn.next().slideUp().parent().removeClass('expand');
		} else {
			$btn.next().slideDown().parent().addClass('expand');
		}
	});

    // Setup mobile tabs
    $('#btn-tabs-toggle').toggle(
        function() {
            $(this).parent().removeClass('collapse').addClass('expand').find('.ui-state-default').slideDown();
        },
        function() {
            $(this).parent().removeClass('expand').addClass('collapse').find('.ui-state-default:not(.ui-state-active)').slideUp();
        }
    );
    //Change CSS when hover on product in Kuler Showcase
    $('.kuler-showcase-module .product-grid').hover(function () {
        $(this).parents('.owl-carousel').css('overflow', 'visible');
    }, function () {
        $(this).parents('.owl-carousel').css('overflow', 'hidden');
    });
	// Remove cleafix
	$('.product-layout + .clearfix').remove();
});
