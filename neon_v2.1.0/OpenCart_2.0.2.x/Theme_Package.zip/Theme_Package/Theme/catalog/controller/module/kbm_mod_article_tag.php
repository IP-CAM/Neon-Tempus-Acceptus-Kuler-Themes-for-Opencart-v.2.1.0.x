<?php
/**
 * Class ControllerModuleKBMModArticleTag
 * @property ModelModuleKBMModArticleTag $model
 * @property ModelKulerBlogManager $kbm_model
 */
class ControllerModuleKBMModArticleTag extends Controller
{
    protected $model;
	protected $kbm_model;
	protected $data = array();

    public function __construct($registry)
    {
        parent::__construct($registry);

	    $this->load->model('kuler/common');
	    $this->common = $this->model_kuler_common;

	    $this->load->model('module/kbm');
	    $this->kbm_model = $this->model_module_kbm;

        $this->load->model('module/kbm_mod_article_tag');
        $this->model = $this->model_module_kbm_mod_article_tag;
    }

    public function index($setting)
    {
	    if (!$this->common->isKulerTheme($this->config->get('config_template')))
	    {
		    return false;
	    }

        static $module = 0;
	    $this->language->load('module/kbm_mod_article_tag');

	    // Get product tags
	    $tags = $this->model->getProductTags();

	    // Calculate font size for each tag
	    $size_tags = array();

	    if ($tags)
	    {
		    $min_size = 10;
		    $max_size = 30;

		    $min = min($tags);
		    $max = max($tags);

			$spread = $max - $min;

		    if ($spread <= 0)
		    {
			    $spread = 1;
		    }

			$step = ($max_size - $min_size) / $spread;

		    foreach ($tags as $tag => $count)
		    {
			    $size_tags[] = array(
				    'tag'   => $tag,
				    'size'  => round($min_size + ($count - $min) * $step),
				    'count' => $count,
				    'link'  => $this->kbm_model->link('module/kbm/search', array('tag' => $tag)),
				    'text_tag' => sprintf($this->language->get('text_x_items_tagged_with_y'), $count, $tag)
		    );
		    }
	    }

	    $this->data['tags'] = $size_tags;

	    // Module Index
	    $this->data['module']   = $module++;

	    // Module title
	    $this->data['show_title']   = $setting['show_title'];
	    if (isset($setting['kbm_mod_article_tag'][$this->config->get('config_language_id')])) {
		    $this->data['title'] = html_entity_decode($setting['kbm_mod_article_tag'][$this->config->get('config_language_id')]['title'], ENT_QUOTES, 'UTF-8');
	    }

	    if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/module/kbm_mod_recent_article.tpl')) {
		    return $this->load->view($this->config->get('config_template') . '/template/module/kbm_mod_recent_article.tpl', $this->data);
	    } else {
		    return $this->load->view('default/template/module/kbm_mod_recent_article.tpl', $this->data);
	    }
    }

	private function translate($texts, $language_id)
	{
		if (is_array($texts))
		{
			$first = current($texts);

			if (is_string($first))
			{
				$texts = empty($texts[$language_id]) ? $first : $texts[$language_id];
			}
			else if (is_array($texts))
			{
				if (!isset($texts[$language_id]))
				{
					$texts[$language_id] = array();
				}

				foreach ($first as $key => $value)
				{
					if (empty($texts[$language_id][$key]))
					{
						$texts[$language_id][$key] = $value;
					}
				}
			}
		}

		return $texts;
	}
}