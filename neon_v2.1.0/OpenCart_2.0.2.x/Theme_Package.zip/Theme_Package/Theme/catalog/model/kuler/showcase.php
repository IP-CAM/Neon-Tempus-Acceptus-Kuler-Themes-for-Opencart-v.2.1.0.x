<?php
class ModelKulerShowcase extends Model {

}