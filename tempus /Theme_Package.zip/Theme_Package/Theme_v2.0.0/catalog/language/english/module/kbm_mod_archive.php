<?php

$_['text_on']   = 'on';