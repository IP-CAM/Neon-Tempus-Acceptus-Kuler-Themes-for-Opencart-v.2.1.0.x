<?php
class ModelModuleKulerFilter extends Model
{
}